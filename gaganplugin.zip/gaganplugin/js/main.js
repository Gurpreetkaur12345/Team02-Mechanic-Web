jQuery(document).ready(function($) {
	$('#slider').nivoSlider();
});